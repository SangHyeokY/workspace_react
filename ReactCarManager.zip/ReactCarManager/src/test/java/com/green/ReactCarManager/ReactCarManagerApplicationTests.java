package com.green.ReactCarManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactCarManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
